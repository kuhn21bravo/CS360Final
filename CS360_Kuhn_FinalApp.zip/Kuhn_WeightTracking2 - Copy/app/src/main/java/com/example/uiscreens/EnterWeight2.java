package com.example.uiscreens;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EnterWeight2 extends AppCompatActivity {
    private TableLayout tl;
    private EditText name,current_weight,goal_weight;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight2);

        tl = (TableLayout) findViewById(R.id.tableLayout);
        name = (EditText)findViewById(R.id.full_names_input);
        current_weight = (EditText)findViewById(R.id.current_weight_input);
        goal_weight = (EditText)findViewById(R.id.goal_weight_input);
    }
    public void AddToTable(View view){


        TableRow tr =new TableRow(this);
        tr.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tr.setBackgroundColor(Color.parseColor("#DAE8FC"));
        tr.setPadding(5,5,5,5);
        TextView tx1 =new TextView(this);
        TextView tx2 =new TextView(this);
        TextView tx3 =new TextView(this);
        String e_name=name.getText().toString(),
                e_current=current_weight.getText().toString(),
                e_goal=goal_weight.getText().toString();
        if(e_name.isEmpty() || e_current.isEmpty()||e_goal.isEmpty()) {
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        tx1.setText(e_name);

        tx2.setText(e_current);

        tx3.setText(e_goal);
        Button btn =new Button(this);
        btn.setText("Delete");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteRow(v);
            }
        });

        tr.addView(tx1);
        tr.addView(tx2);
        tr.addView(tx3);
        tr.addView(btn);
        tl.addView(tr);

        name.setText("");
        current_weight.setText("");
        goal_weight.setText("");
    }
    public void deleteRow(View v){
        View row =(View)v.getParent();
        ViewGroup container =((ViewGroup)row.getParent());
        container.removeView(row);
        container.invalidate();
    }
}
