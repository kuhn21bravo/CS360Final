package com.example.uiscreens;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class databaseActivity extends AppCompatActivity {
    private TableLayout tl;
    private EditText name,postal_code,phone_number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

         tl = (TableLayout) findViewById(R.id.tableLayout);
         name = (EditText)findViewById(R.id.full_names_input);
         postal_code = (EditText)findViewById(R.id.postal_code_input);
         phone_number = (EditText)findViewById(R.id.phone_number_input);
    }
    public void AddToTable(View view){


        TableRow tr =new TableRow(this);
        tr.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tr.setBackgroundColor(Color.parseColor("#DAE8FC"));
        tr.setPadding(5,5,5,5);
        TextView tx1 =new TextView(this);
        TextView tx2 =new TextView(this);
        TextView tx3 =new TextView(this);
        String e_name=name.getText().toString(),
                e_postal=postal_code.getText().toString(),
                e_phone=phone_number.getText().toString();
        if(e_name.isEmpty() || e_postal.isEmpty()||e_phone.isEmpty()) {
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        tx1.setText(e_name);

        tx2.setText(e_postal);

        tx3.setText(e_phone);
        Button btn =new Button(this);
        btn.setText("Delete");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteRow(v);
            }
        });

        tr.addView(tx1);
        tr.addView(tx2);
        tr.addView(tx3);
        tr.addView(btn);
        tl.addView(tr);

        name.setText("");
        postal_code.setText("");
        phone_number.setText("");
    }
    public void deleteRow(View v){
        View row =(View)v.getParent();
        ViewGroup container =((ViewGroup)row.getParent());
        container.removeView(row);
        container.invalidate();
    }
}
